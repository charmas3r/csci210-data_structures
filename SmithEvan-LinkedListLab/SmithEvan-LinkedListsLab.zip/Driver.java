import java.io.*;

/**
 * Driver Class for the Payroll Processing lab as shown on page 329 of 
 * Professor Stegman's book "Focus on Data Structures"
 * 
 * @author Evan Smith 
 * @version 4/28/17
 */
public class Driver {
    
    public static void main(String[] args) throws InterruptedException, IOException {
        
    PrintWriter pw = new PrintWriter(new FileWriter("csis.txt"));
    Payroll temp = new Payroll(pw);
    
    temp.payroll();
    temp.size();
    temp.getWomen();
    temp.highEarners();
    temp.raise();
    temp.getSortedList();
    temp.getHirefile();
    temp.getFirefile();
    
    pw.close();
    }
}
