
/**
 * ObjectListNode is a compliation of primitive operations for Object list nodes to be used with the 
 * ObjectList class in a linear linked list. 
 * 
 * @implements ObjectListNodeInterface
 * @author Evan Smith
 * @version 4/28/2017
 */

public class ObjectListNode implements ObjectListNodeInterface {
	private Object info;
	private ObjectListNode next;

	/**
     * Default ctor creates empty node setting info and next to null
     */
	public ObjectListNode() {
		info = null;
		next = null;
	}

	/**
     * One-Arg ctor creates node with Object value pointing to null
     */
	public ObjectListNode(Object o) {
		info = o;
		next = null;
	}

	/**
     * Constructor creates an Object node pointing to another node
     */
	public ObjectListNode(Object o, ObjectListNode p) {
		info = o;
		next = p;
	}

    /**
     * This method changes the info value of a node
     */
	public void setInfo(Object o) {
		info = o;
	}

	/**
     * This method retrieves the value of a node
     * @return info
     */
	public Object getInfo() {
		return info;
	}

	/**
     * This method changes the node pointed to 
     */
	public void setNext(ObjectListNode p) {
		next = p;
	}

	/**
     * This method retrieves the next node pointed to be the current node 
     * @return next
     */
	public ObjectListNode getNext() {
		return next;
	}
}