
/**
 * Employee class gets and sets certain parameters which are implemented in the Payroll class. 
 * 
 * @author Evan Smith
 * @version 4/25/17
 */
public class Employee implements Comparable{
    
    private String firstName;
    private String lastName;
    private char gender;
    private int years;
    private char payRate;
    private double salary;
    
    /**
     * This constructor initalizes the first and last name of an Employee object
     * 
     */
        public Employee(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * This constructor intializes the first name, last name, gender, tenure, payrate and salary
     * amount of an Employee
     * 
     */
    public Employee(String firstName, String lastName, char gender, int years, char payRate, double amount) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.years = years;
        this.payRate = payRate;
        this.salary = amount;
    }
   
    /**
     * This method gets the first name of an Employee object
     * @return firstName
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * This method gets the last name of an Employee object
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * This method gets the gender of an Employee object
     * @return gender
     */
    public char getGender() {
        return gender;
    }
    
    /**
     * This method gets the tenure of an Employee object
     * @return years
     */
    public int getYears() {
        return years;
    }
    
    /**
     * This method gets the pay rate of an Employee object
     * @return payRate
     */
    public char getPayRate() {
        return payRate;
    }
    
    /**
     * This method gets the salary of an Employee object
     * @return salary
     */
    public double getSalary() {
        return salary;
    }

    /**
     * This method sets the salary of an Employee object
     * 
     */
    public void setSalary(double amount) {
        salary = amount;
    }
    
    /**
     * This method compares the last names two employee objects for sorting purposes
     * @return integer comparison
     */
    public int compareTo(Object o) {
        Employee temp = (Employee)o;
        return lastName.compareTo(temp.getLastName());
    }

}
