
/**
 * ObjectListNodeInterface to be used with ObjectListNode class.
 * 
 * @author Evan Smith 
 * @version 4/28/2017
 */

public interface ObjectListNodeInterface {
	public void setInfo(Object o);
	public Object getInfo();
	public void setNext (ObjectListNode p);
	public ObjectListNode getNext();
}

