
/**
 * Comparable interface to be used with the Employee and ObjectList class
 * 
 * @author Evan Smith 
 * @version 4/28/2017
 */

public interface Comparable {
	public int compareTo(Object o);
}

