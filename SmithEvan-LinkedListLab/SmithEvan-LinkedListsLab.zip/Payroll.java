import java.io.*;
import java.util.Scanner;

/**
 * Driver Class for the Payroll Processing lab as shown on page 329 of 
 * Professor Stegman's book "Focus on Data Structures"

 * @author Evan Smith 
 * @version 4/28/17
 */
public class Payroll {
    public static final double HOURLY_RAISE = .75;
    public static final double WEEKLY_RAISE = 50.0;
    
    private PrintWriter pw;
    
    private ObjectList payList;
    private ObjectList database;
    private ObjectList womenList;
    private ObjectList raiseList;
    private ObjectList sortedList;
    private ObjectList tempList;
    
    private int totalEmployees;
    private double salary;
    
    /**
     * This constructor initalizes the instance variabels
     * @param pw  PrintWriter object passed by driver class
     */
    public Payroll(PrintWriter pw){
        this.pw = pw;
        
        this.payList = new ObjectList();
        this.database = new ObjectList();
        this.womenList = new ObjectList();
        this.raiseList = new ObjectList();
        this.sortedList = new ObjectList();
        this.tempList = new ObjectList();
        
        totalEmployees = 0;
        salary = 0.0; 
    }
    
    /**
     * This method gets the payroll information and outputs the database of employees
     * @throws InterruptedException
     * @throws IOException
     */
    public void payroll() throws InterruptedException, IOException {
        getPayroll();
        outputHeader();
        employeeDB();
    }

        /**
     * This method uses the sort method to out a sorted list of employees
     * @throws InterruptedException
     * @throws IOException
     */
    public void getSortedList() throws InterruptedException, IOException {
        sort();
        System.out.println("Database of employees sorted in alphabetical order:\n");
        pw.println("Database of employees sorted in alphabetical order:\n");
        
        ObjectListNode p = database.getFirstNode();
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();

            System.out.printf("%-8s %-8s %15.2f \n", 
                    temp.getFirstName(), 
                    temp.getLastName(),  
                    temp.getSalary());
            
            pw.println(String.format("%-8s %-8s %15.2f \n", 
                    temp.getFirstName(), 
                    temp.getLastName(),  
                    temp.getSalary()));        
                    
            p = p.getNext();

        }
        
        System.out.println("\n");
        pw.println("\n");
    }
    
        /**
     * This method scans employee info in from the payfile and adds them to a linked list and then
     * creates a database from the list. 
     * @throws InterruptedException
     * @throws IOException
     */
    public void getPayroll() throws InterruptedException, IOException{
        Scanner fileScan = new Scanner(new File("payfile.txt"));
        
        while(fileScan.hasNext()){
            String buf = fileScan.nextLine(); //get whole line
            String delims = "[ ]+"; 
            String[] tokens = buf.split(delims); //parse line into tokens
            
            Employee temp = new Employee(tokens[0], tokens[1], tokens[2].charAt(0), Integer.parseInt(tokens[3]), tokens[4].charAt(0), Float.parseFloat(tokens[5]));
            payList.addLast(temp); //inserts Employee object into the end of ObjectList
        }
        
        fileScan.close();
        database = payList.copyList(); // copy contents of Employee list to database List
    }   
    
    /**
     * This method scans in employees from the hirefile and inserts them into the database.
     * @throws InterruptedException
     * @throws IOException
     */
    public void hirefile() throws InterruptedException, IOException {
        Scanner fileScan = new Scanner(new File("hirefile.txt"));
        
        while(fileScan.hasNext()){
            String buf = fileScan.nextLine(); //get whole line
            String delims = "[ ]+"; 
            String[] tokens = buf.split(delims); //parse line into tokens
            
            Employee temp = new Employee(tokens[0], tokens[1], tokens[2].charAt(0), Integer.parseInt(tokens[3]), tokens[4].charAt(0), Float.parseFloat(tokens[5]));
            database.insert(temp); //inserts Employee object into correct location
            
        }
        fileScan.close();
    }  
    
    /**
     * This method uses the hirefile method to fetch new hires and outputs their first and last names
     * @throws InterruptedException
     * @throws IOException
     */
    public void getHirefile() throws InterruptedException, IOException {
        hirefile();
        System.out.println("Database of employees after new hires:\n");
        pw.println("Database of employees after new hires:\n");
               
        ObjectListNode p = database.getFirstNode();
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();

            System.out.printf("%-8s %-8s \n", 
                    temp.getFirstName(), 
                    temp.getLastName());
                    
            pw.println(String.format("%-8s %-8s \n", 
                    temp.getFirstName(), 
                    temp.getLastName()));

            p = p.getNext();

        }
        
        pw.println("\n");
        System.out.println("\n");
    }
    
    /**
     * This method fetchs the employees to be fired, then fires them and outputs the updated 
     * database according to first and last name. 
     * @throws InterruptedException
     * @throws IOException
     */
    public void getFirefile() throws InterruptedException, IOException {
        firefile();
        fire();
        
        ObjectListNode p = database.getFirstNode();
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();
            
            System.out.printf("%-8s %-8s \n", 
                    temp.getFirstName(), 
                    temp.getLastName());
           
            pw.println(String.format("%-8s %-8s \n", 
                    temp.getFirstName(), 
                    temp.getLastName()));     
                    
            p = p.getNext();        
        }
        
        System.out.println("\n");
        pw.println("\n");
    }
    
    /**
     * This method scans in employees from the firefile and inserts them into a temporary list
     * @throws InterruptedException
     * @throws IOException
     */
    public void firefile() throws InterruptedException, IOException {
        Scanner fileScan = new Scanner(new File("firefile.txt"));
        
        //needs work
        while(fileScan.hasNext()){
            String buf = fileScan.nextLine(); //get whole line
            String delims = "[ ]+"; 
            String[] tokens = buf.split(delims); //parse line into tokens
            
            Employee temp = new Employee(tokens[0], tokens[1]);
            tempList.addLast(temp); //iremove first occurance of employee from database
        }
        fileScan.close();
        
        System.out.println("Database of employees after firing:\n");
        pw.println("Database of employees after firing:\n");

    }  
    

    /**
     * This method removes an employee found in the tempList from the database
     * 
     */
    public void fire() {
        ObjectListNode p = tempList.getFirstNode();

        while (p != null) {
            Employee temp = (Employee) p.getInfo();
            database.remove(temp);
            p = p.getNext();
        }
    }
    
    /**
     * This method creates a linear linked list of females from the database list and prints 
     * the total amount of women currently employed.
     * 
     */
    public void getWomen() {
        ObjectListNode p = database.getFirstNode();
        
        System.out.println("Current list of all women on the payroll:\n");
        pw.println("Current list of all women on the payroll:\n");
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();
            
            if (temp.getGender() != 'M') {
            System.out.printf("%-8s %-8s \n", 
                    temp.getFirstName(), 
                    temp.getLastName());
           
            pw.println(String.format("%-8s %-8s \n", 
                    temp.getFirstName(), 
                    temp.getLastName())); 
                    
            womenList.addLast(temp);
            }
            p = p.getNext();
        }
        
        System.out.println();    
        System.out.printf("The total number of women currently employed: %d\n", womenList.size());  
        System.out.println("\n");
        
        pw.println();    
        pw.println("The total number of women currently employed: " + womenList.size());  
        pw.println("\n");
        
    }
    
    /**
     * This method prints the first name, last name and salary of all weekly employees who make 
     * more than 35k yearly and have been with the company for at least 5 years. 
     * 
     */
    public void highEarners() {
        ObjectListNode p = database.getFirstNode();
        
        System.out.println("Weekly employees who make more than 35000 and have been with the company at least 5 years:\n");
        pw.println("Weekly employees who make more than 35000 and have been with the company at least 5 years:\n");
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();

            if (temp.getYears() >= 5) {
                if (temp.getPayRate() == 'W' && (temp.getSalary() * 52 >= 35000)) {
                    System.out.printf("%-8s %-8s %15.2f \n", 
                            temp.getFirstName(), 
                            temp.getLastName(),  
                            temp.getSalary());
                            
                    pw.println(String.format("%-8s %-8s %15.2f \n", 
                            temp.getFirstName(), 
                            temp.getLastName(),  
                            temp.getSalary())); 
                }    
            }
            p = p.getNext();
        }
        
        System.out.println("\n");
        pw.println("\n");
    }
    
    /**
     * This method gives a raise of 75 cents to all employees paid an hourly wage under $10.00 and 
     * a $50.00 raise to all employees paid a weekly wage less than $350.00. The method then
     * prints the first name, last name, and updated salary of these people.
     * 
     */
    public void raise() {
        ObjectListNode p = database.getFirstNode();
        
        System.out.println("Raises given to:\n");
        pw.println("Raises given to:\n");
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();
     
                if (temp.getPayRate() == 'H' && (temp.getSalary() < 10.0 )) {
                    salary = temp.getSalary() + HOURLY_RAISE;
                    temp.setSalary(salary);
                    raiseList.addLast(temp);
                }
                if (temp.getPayRate() == 'W' && (temp.getSalary() < 350.0 )) {
                    salary = temp.getSalary() + WEEKLY_RAISE;
                    temp.setSalary(salary);
                    raiseList.addLast(temp);
                }    
            p = p.getNext();
        }
        
        ObjectListNode q = raiseList.getFirstNode();
        
        while (q != null) {
            Employee raiseTemp = (Employee) q.getInfo();
            
            System.out.printf("%-8s %-8s %15.2f \n", 
                    raiseTemp.getFirstName(), 
                    raiseTemp.getLastName(),  
                    raiseTemp.getSalary());
                    
            pw.println(String.format("%-8s %-8s %15.2f \n", 
                    raiseTemp.getFirstName(), 
                    raiseTemp.getLastName(),  
                    raiseTemp.getSalary()));
 
            q = q.getNext();
        }
        
        pw.println("\n");
        System.out.println("\n");
    }
    
    /**
     * This method prints how many employees are currently with the company
     * 
     */
    public void size() {
        totalEmployees = database.size();
        
        System.out.println();
        System.out.printf("The total number of Employees is currently: %d\n\n", totalEmployees);
        System.out.println();
        
        pw.println();
        pw.println("The total number of Employees is currently: " + totalEmployees);
        pw.println();
    }
    
    /**
     * This method sorts all employees in alphabetical order
     * 
     */
    public void sort() {
        ObjectListNode p = database.getFirstNode();
        
        while (p != null) {
            Employee temp = (Employee) p.getInfo();
            sortedList.insert(temp);
            p = p.getNext();
        }
        
        database = sortedList.copyList();
    }
    
    /**
     * This method creates the output header table
     * 
     */
    public void outputHeader() {
        System.out.printf("%-8s %-8s %11s %8s %9s %12s \n",
                    "FIRST",
                    "LAST", 
                    "GENDER", 
                    "TENURE", 
                    "PAYRATE",
                    "SALARY");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println();
        
        pw.println(String.format("%-8s %-8s %11s %8s %9s %12s \n",
                    "FIRST",
                    "LAST", 
                    "GENDER", 
                    "TENURE", 
                    "PAYRATE",
                    "SALARY"));
        pw.println("-------------------------------------------------------------------------");
        pw.println(); 
    }
    
    /**
     * This method creates the database of employees and fills in the outputHeader table
     * 
     */
    public void employeeDB () {
        ObjectListNode p = database.getFirstNode();
        
        while(p != null) {
            Employee temp = (Employee) p.getInfo();

            System.out.printf("%-8s %-8s %8c %8d %8c %15.2f \n", 
                    temp.getFirstName(), 
                    temp.getLastName(), 
                    temp.getGender(), 
                    temp.getYears(), 
                    temp.getPayRate(), 
                    temp.getSalary());
                    
            pw.println(String.format("%-8s %-8s %8s %8s %8s %15.2f \n", 
                    temp.getFirstName(), 
                    temp.getLastName(), 
                    temp.getGender(), 
                    temp.getYears(), 
                    temp.getPayRate(), 
                    temp.getSalary()));

            p = p.getNext(); // onto the next node
        }
        
        System.out.println("\n");
        pw.println("\n");
    }
}