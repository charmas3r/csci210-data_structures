import java.io.*;
import java.util.Scanner;

/**
* This is MFQ Class which runs the Multi Level Feedback Queue simulation as described on page 208
* in Professor Stegman's book "Focus on Data Structures"
* 
* @author Evan Smith
* @version 4/6/2017
*/
public class MFQ {
    private PrintWriter pw;
    
    private ObjectQueue inputQueue;
    private ObjectQueue queue1;
    private ObjectQueue queue2;
    private ObjectQueue queue3;
    private ObjectQueue queue4;
    
    private int sysClock;
    private int totalJobs;
    private int totalTime;
    private int total_Idle_Time;
    private int totalArriveTime;
    private int totalDepartureTime;
    private int totalCpuTimeNeeded;
    private int timeInSystem;
    private int avgResponseTime;
    private int avgTurnAround;
    private int avgWaitTime;
    private float avgThroughput;
    
    /**
     * This method is the class constructor for MFQ class.
     * @param pw    PrintWriter object
     */
    public MFQ(PrintWriter pw){

        this.pw = pw;
        this.inputQueue = new ObjectQueue();
        this.queue1 = new ObjectQueue();
        this.queue2 = new ObjectQueue();
        this.queue3 = new ObjectQueue();
        this.queue4 = new ObjectQueue();
        
        this.sysClock = 0;
    }
    
    /**
     * This method retrieves the jobs from input file and sends jobs to input queue
     * @throws InterruptedException
     * @throws IOException
     */
    public void getJobs() throws InterruptedException, IOException{
        Scanner fileScan = new Scanner(new File("mfq.txt"));
        
        while(fileScan.hasNext()){
            String buf = fileScan.nextLine(); //get whole line
            String delims = "[ ]+"; 
            String[] tokens = buf.split(delims); //parse line into tokens
            
            Job temp = new Job(Integer.parseInt(tokens[0]),Integer.parseInt(tokens[1]),Integer.parseInt(tokens[2]), 0);
            inputQueue.insert(temp);
            

        }
    }
    
    /**
     * This method runs the multi-level feed back queue simulation
     * @throws InterruptedException
     */
    public void runSimulation() throws InterruptedException{
        boolean preemption = false;
        CPU cpu = new CPU();
        
        while (sysClock < 156) { // system clock runs for a total of 156 seconds
            
            // below is all the processes that happen in within the second of sysClock
            if (!inputQueue.isEmpty()) {
                Job tempJob = (Job) inputQueue.query(); //returns front job 
                
                if(tempJob.getArrivalTime() == sysClock) {
                    queue1.insert((Job) inputQueue.remove()); 
                    // submit new job into queue1 from queue1 and output message
                    
                    totalJobs++; 
                    totalArriveTime += sysClock;
                    totalCpuTimeNeeded += tempJob.getCpuTimeRequired();
                    
                    
                    System.out.println("ARRIVAL" + " \t" + sysClock + "\t" + tempJob.getPID() + "\t \t" + tempJob.getCpuTimeRequired() + "\t \t \t" + "-" + "\t \t \t" + "-");
                    pw.println("ARRIVAL" + " \t" + sysClock + "\t" + tempJob.getPID() + "\t \t" + tempJob.getCpuTimeRequired() + "\t \t \t" + "-" + "\t \t \t" + "-");
                }
            }
            
            if (cpu.getBusyFlag() == true) {
                cpu.RunCPU(); // runs current job in cpu
                
                if(!queue1.isEmpty() || cpu.getQuantumClock() == 0)
                    preemption = true; 
                // requisite for preemption p.215

                if(cpu.getCPUjob().getCpuTimeRemaining() == 0) {
                    
                    timeInSystem = sysClock - cpu.getCPUjob().getArrivalTime();
                    totalTime += timeInSystem;
                    totalDepartureTime += sysClock;
                    
                    System.out.println("DEPARTURE" + "\t" + sysClock + "\t" + cpu.getCPUjob().getPID() + "\t \t" + "-"  + "\t \t \t" + timeInSystem + "\t \t \t" + cpu.getCPUjob().getCurrentLevel());
                    pw.println("DEPARTURE" + "\t" + sysClock + "\t" + cpu.getCPUjob().getPID() + "\t \t" + "-"  + "\t \t \t" + timeInSystem + "\t \t \t" + cpu.getCPUjob().getCurrentLevel());
                    
                    cpu= new CPU();
                    preemption = false; 
                }
            }
            
            if (preemption == true) {       
                
                Job reducedJob = new Job(cpu.getCPUjob().getArrivalTime(),cpu.getCPUjob().getPID(), cpu.getCPUjob().getCpuTimeRemaining(), cpu.getCPUjob().getCurrentLevel() + 1);
                moveNextLevel(reducedJob, reducedJob.getCurrentLevel());
                
                cpu = new CPU();
                preemption = false;
            }
            
            if(cpu.getBusyFlag() == false) {
                moveToCPU(cpu);
                
            }
            
            sysClock++;
        }
        
        avgTurnAround = (totalDepartureTime - totalArriveTime) / totalJobs;
        // interval from time a process enters to completion
        avgThroughput = (float)totalJobs / (float)totalTime; 
        // #jobs / sum of total time of all jobs
        avgWaitTime = (totalTime - totalCpuTimeNeeded) / totalJobs;
        // time process is kept waiting in queue
    }
    
    /**
    * This method removes the job from queue and places it into the CPU.
    * @param cpu   cpu object 
    */
    public void moveToCPU(CPU cpu) {
        if (!queue1.isEmpty()){
            cpu.setJob((Job) queue1.remove(), 1);
            cpu.setBusyFlag(true);
            
        }
        else if (!queue2.isEmpty()){
            cpu.setJob((Job) queue2.remove(), 2);
            cpu.setBusyFlag(true);
            
        }
        else if (!queue3.isEmpty()){
            cpu.setJob((Job) queue3.remove(), 3);
            cpu.setBusyFlag(true);
            
        }
        else if (!queue4.isEmpty()){
            cpu.setJob((Job) queue4.remove(), 4);
            cpu.setBusyFlag(true);
            
        }
        else {
            total_Idle_Time++;  
        }
    }
    
    /**
    * This method sends job to next LLQ
    * 
    * @param reducedJob
    * @param level
    */
    public void moveNextLevel(Job reducedJob, int level) {
        if (level == 2){
            queue2.insert(reducedJob);
        }
        else if (level == 3){
            queue3.insert(reducedJob);  
        }
        else if (level >= 4){
            queue4.insert(reducedJob);      
        }
    }
    
    /**
    * This method outputs the required statistics
    */
    public void outStats(){
        System.out.println();
        System.out.println("MFQ Simulation Stats:");
        System.out.println("Total # of jobs: " + totalJobs);
        System.out.println("Total time of all jobs: " + totalTime);
        System.out.println("Average response time: " + avgResponseTime);
        System.out.println("Average turnaround time: " + avgTurnAround);
        System.out.println("Average wait time: " + avgWaitTime);
        System.out.println("Average throughput: " + avgThroughput);
        System.out.println("Total idle time: " + total_Idle_Time);
        
        pw.println();
        pw.println("MFQ Simulation Stats:");
        pw.println("Total jobs: " + totalJobs);
        pw.println("Total time of all jobs: " + totalTime);
        pw.println("Average response time: " + avgResponseTime);
        pw.println("Average turnaround time: " + avgTurnAround);
        pw.println("Average wait time: " + avgWaitTime);
        pw.println("Average throughput: " + avgThroughput);
        pw.println("Total idle time: " + total_Idle_Time);
    }
    
    /**
    * This method outputs the header of the job information.
    */
    public void outputHeader(){
        System.out.println("EVENT \t SYSTEM TIME    PID \t CPU TIME NEEDED \t TOTAL TIME IN SYS \t LOWEST LEVEL QUEUE \t");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        System.out.println("-------------------------------------------------------------------------------------------------------------");
        System.out.println();
        
        pw.println("EVENT \t SYSTEM TIME    PID \t CPU TIME NEEDED \t TOTAL TIME IN SYS \t LOWEST LEVEL QUEUE \t");
        pw.println("---------------------------------------------------------------------------------------------------------------------");
        pw.println("---------------------------------------------------------------------------------------------------------------------");
        pw.println();
        
    }
}