/**
* This is the CPU class for the MFQ system simulation
* @author Evan Smith
*/
public class CPU {
    private Job currentJob;
    private int quantumTime;
    private int quantumClock;
    private int jobClock;
    private boolean busyFlag;
    
    /**
     * This is the default constructor for CPU class.
     */
    public CPU (){
        this.currentJob = new Job(0, 0, 0, 0);
        this.quantumTime = 0;
        this.quantumClock = 0;
        this.jobClock = 0;
        this.busyFlag = false;
        
    }
    
    /**
    * This method sets the current job in the CPU.
    * @param newjob
    * @param level
    */
    public void setJob(Job newJob, int level){
        currentJob = newJob;
        currentJob.setCurrentLevel(level);
        jobClock = currentJob.getCpuTimeRequired();
        quantumClock = getQuantum(currentJob.getCurrentLevel());
    }
    
    /**
    * This method runs the job in the cpu by decrementing the quantum clock and job clock.
    */
    public void RunCPU(){
        if (quantumClock > 0) {
            --quantumClock;
            --jobClock;
            currentJob.setTimeRemaining(jobClock);
        }

    }
    
    /**
    * This method gets the quantum time of current job
    * @param level current queue level
    * @return quantumTime time associated with queue level
    */
    public int getQuantum(int level){
        if (level == 1) 
            quantumTime = 2;
        else if (level == 2)
            quantumTime = 4;
        else if (level == 3)
            quantumTime = 8;
        else 
            quantumTime = 16;
        
        return quantumTime;
    }
    
        /**
    * This method returns the current job's quantum time
    * @return quantumClock
    */
    public int getQuantumClock(){
        return quantumClock;
    }
    
    /**
    * This method sets the busyflag in the cpu.
    * @param status
    */
    public void setBusyFlag(boolean status){
        busyFlag = status;
    }
    
        /**
    * This method lets us know if CPU is busy
    * @return busyFlag
    */
    public boolean getBusyFlag(){
        return busyFlag;
    }
    
    /**
    * This method returns the current job in the CPU
    * @return currentJob
    */
    public Job getCPUjob(){
        return currentJob;
    }
    
    /**
    * This method returns the current job's time remaining in the cpu.
    * @return jobClock
    */
    public int getJobClock(){
        return jobClock;
    }
    

    

}

