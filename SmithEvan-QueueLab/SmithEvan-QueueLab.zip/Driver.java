import java.io.*;

/**
 * Driver Class for the Multi-Level Feedback Queue simulation as shown on page 214 of 
 * Professor Stegman's book "Focus on Data Structures"
 * 
 * @author Evan Smith
 * @version 4/6/17
 */
public class Driver
{
   public static void main(String[] args) throws InterruptedException, IOException{
       PrintWriter pw = new PrintWriter(new FileWriter("csis.text"));
       MFQ mfq = new MFQ(pw);
       mfq.getJobs();
       mfq.outputHeader();
       mfq.runSimulation();
       mfq.outStats();
       pw.close();
    }
}
