/**
* This is the Job Class for the MFQ simulation
* @author Evan Smith
*/

public class Job {
    private int pid;
    private int arrivalTime;
    private int cpuTimeRequired;
    private int cpuTimeRemaining;
    private int currentLevel;
    
    /**
    * This method is a class constructor for Job Class
    * @param arrival   arrival time
    * @param pid   job ID
    * @param timeRequired   required time
    * @param level   queue level
    */
    public Job(int arrival, int pid, int timeRequired, int level){
        this.arrivalTime = arrival;
        this.pid = pid;
        this.cpuTimeRequired = timeRequired;
        this.cpuTimeRemaining = timeRequired;
        this.currentLevel = level;
    }
    
    /**
    * This method returns the arrival time of job.
    * @return arrivalTime
    */
    public int getArrivalTime(){
        return arrivalTime;
    }
    
    /**
    * This method returns the PID of job.
    * @return pid
    */
    public int getPID(){
        return pid;
    }
    
    /**
    * This method returns the current level queue of job.
    * @return currentLevel
    */
    public int getCurrentLevel(){
        return currentLevel;
    }
    
    /**
    * This method returns the time required of job.
    * @return cpuTimeRequired
    */
    public int getCpuTimeRequired(){
        return cpuTimeRequired;
    }
    
    /**
    * This method returns the time remaining of job.
    * @return cpuTimeRemaining
    */
    public int getCpuTimeRemaining(){
        return cpuTimeRemaining;
    }
    
    /**
    * This method sets the queue level of job.
    * @param level
    */
    public void setCurrentLevel(int level) {
        currentLevel = level;
    }
    
    /**
    * This method sets the time remaining of job.
    * @param time
    */
    public void setTimeRemaining(int time){
        cpuTimeRemaining = time;
    }
}