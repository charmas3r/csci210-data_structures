
/**
 * ObjectBinaryTree class contains a set of methods to be used with the implementation of a binary tree data
 * structure within the Binary Trees Lab as presented on page 453 of Professor Stegman's "Focus on Data
 * Structures 6th Edition". Further detailing of these methods can be found on Page 368-386 of this text. 
 * 
 * @implements ObjectBinaryTreeInterface
 * @author Evan Smith
 * @version 5/16/17
 */

public class ObjectBinaryTree implements ObjectBinaryTreeInterface {
    private ObjectTreeNode root;
    
    /**
     * Default constructor initializes the root node of the binary tree to null
     * 
    */
    public ObjectBinaryTree() {
        root = null;
    }
    
    /**
     * One-arg constructor returns the root node of the binary tree
     * 
     * @return  root    root node of the binary tree
    */
    public ObjectTreeNode getRoot() {
        return root;
    }
    
    /**
     * This method gives a left child to the parent node passed into the method.
     * 
     * @param   parent  parent node
     * @param   r       node set to left child
    */
    public void setLeftChild(ObjectTreeNode parent, ObjectTreeNode r) {
        if (parent == null || parent.getLeft() != null) {
            System.out.println("Runtime Error: setLeftChild()");
            System.exit(1);
        }
        parent.setLeft(r);
    }
    
    /**
     * This method gives a right child to the parent node passed into the method.
     * 
     * @param   parent  parent node
     * @param   r       node set to right child
    */
    public void setRightChild(ObjectTreeNode parent, ObjectTreeNode r){
        if (parent == null || parent.getRight() != null) {
            System.out.println("Runtime Error: setRightChild()");
            System.exit(1);
        }
        parent.setRight(r);
    }

    /**
     * This method inserts a node into its correct position in a binary search tree. 
     * 
     * @param   o   Object to be inserted in the binary search tree
    */
    public void insertBST(Object o) {
        ObjectTreeNode p, q;
                
        ObjectTreeNode r = new ObjectTreeNode(o);
        if (root == null)
            root = r;
        else {
            p = root;
            q = root;
            while (q != null) {
                p = q;
                if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) < 0 )
                    q = p.getLeft();
                else
                    q = p.getRight();
            }
            if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) < 0)
                setLeftChild(p, r);
            else
                setRightChild(p, r);
        }
    }

    /**
     * This method gives a left child to the parent node passed into the method.
     * 
     * @param   parent  parent node
     * @param   r       node set to left child
    */
    public void insertBSTDup(Object o) {
        ObjectTreeNode p, q;
                
        ObjectTreeNode r = new ObjectTreeNode(o);
        if (root == null)
            root = r;
        else {
            p = root;
            q = root;
            while (q != null && ((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) != 0) {
                p = q;
                if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) < 0)
                    q = p.getLeft();
                else
                    q = p.getRight();
            }
            if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) < 0)
                setLeftChild(p, r);
            else if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) > 0)
                setRightChild(p, r);
            else ((TreeComparable)(p.getInfo())).operate((TreeComparable)(r.getInfo()));
        }
    }

    /**
     * This method searchs a binary search tree for a data value and returns a pointer to the appropiate
     * tree node if the Object value is found
     * 
     * @param   o   Object to be searched for                    
     * @return  ObjectTreeNode  pointer to found Object value else returns null
    */
    public ObjectTreeNode searchBST(Object o) {
        ObjectTreeNode p;
                
        ObjectTreeNode r = new ObjectTreeNode(o);
        if(root != null) {
            p = root;
            while (p != null) {
                if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) < 0)
                    p = p.getLeft();
                else if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) > 0)
                    p = p.getRight();
                else 
                    return p;
            }
        }
        return null;
    }

    /**
     * This recursive method performs a preorder traversal of a binary tree by visiting the root, traversing left subtree
     * in preorder, and then traversing the right subtree in preorder.
     * 
     * @param   ObjectTreeNode parent node
    */
    public void preTrav(ObjectTreeNode tree) {
        if (tree != null) {
            ((TreeComparable)tree.getInfo()).visit();
            preTrav(tree.getLeft());
            preTrav(tree.getRight());
        }
    }
   
    /**
     * This recursive method performs an inorder traversal of a binary tree by traversing left subtree
     * in inorder, visiting the root, and then traversing the right subtree in inorder.
     * 
     * @param   ObjectTreeNode  parent node
    */
    public void inTrav(ObjectTreeNode tree) {
        if (tree != null) {
            inTrav(tree.getLeft());
            ((TreeComparable)tree.getInfo()).visit();
            inTrav(tree.getRight());
        }
    }
      
    /**
     * This recursive method performs a postorder traversal of a binary tree by traversing left subtree
     * in postorder, traversing the right subtree in postorder, and then visiting the root.
     * 
     * @param   ObjectTreeNode  parent node
    */
    public void postTrav(ObjectTreeNode tree) {
        if (tree != null) {
            postTrav(tree.getLeft());
            postTrav(tree.getRight());
            ((TreeComparable)tree.getInfo()).visit();
        }
    }

    /**
     * This method removes a node into its correct position in a binary search tree. 
     * 
     * @param   o   Object to be deleted in the binary search tree
    */
    public void delete(Object o) {
        ObjectTreeNode s, t, v;
        boolean found = false;
                
        ObjectTreeNode r = new ObjectTreeNode(o);
        ObjectTreeNode p = root;
        ObjectTreeNode q = null;
        // Search for the node with info key, set p to point to 
        // that node and set q to point to its parent, if any.
        while (p != null && !found) {
            if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) == 0)
                found = true;
            else {
                q = p;
                if (((TreeComparable)(r.getInfo())).compareTo((TreeComparable)(p.getInfo())) < 0)
                    p = p.getLeft();
                else
                    p = p.getRight();
            }
        }
        if (found) {
            // Set v to point to the node that will replace the node 
            // that p points to.
            if (p.getLeft() == null)
                v = p.getRight();
            else if (p.getRight() == null)
                v = p.getLeft();
            else {
                // the node that p points to has two children;
                // set v to the inorder successor of p;
                // set t to the parent of v
                t = p;
                v = p.getRight();
                s = v.getLeft();  // s is the left child of v
                while (s != null) {
                    t = v;
                    v = s;
                    s = v.getLeft();
                }
                // At this point, v is the inorder successor of p
                if (t != p) {
                    // p is not the parent of v and v = t.getLeft()
                    t.setLeft(v.getRight());
                    // Remove the node that v points to from its
                    // current position to take the place of the 
                    // node that p points to.
                    v.setRight(p.getRight());
                }
                v.setLeft(p.getLeft());
            }
            // Insert the node that v points to into the position
            // formally occupied by the node that p points to
            if (q == null)
                // The node that p points to was the root of the tree
                root = v;
            else if (p == q.getLeft())
                q.setLeft(v);
            else q.setRight(v);
        }
    }
}

