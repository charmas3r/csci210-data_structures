import java.io.*;

/**
 * Driver class for Binary Trees Lab as presented on page 453 of Professor Stegman's "Focus on Data
 * Structures 6th Edition". Driver class first parses both the getty text and words to be omitted, 
 * builds a binary search tree from word objects created in the Xref class, then outputs the full
 * getty text prefixed by line numbers. A table is then displayed showing the results of an inorder
 * traversal of the binary search tree. The query system is then activated for run time queries on words
 * contained in the getty text. The hash table is then displayed with collision statistics and a 
 * description printed for the hash function.
 * 
 * @author Evan Smith 
 * @version 5/19/17
 */
public class Driver {
    public static void main(String[] args) throws InterruptedException, IOException {
            PrintWriter pw = new PrintWriter(new FileWriter("csis.txt"));
            
            Hash hashRef = new Hash(pw);
            Xref temp = new Xref(hashRef, pw);
            Query search = new Query(temp, pw, hashRef);
           
            //parse omitFile first
            temp.omitFile();
            temp.parseFile();
            temp.headerOutput();
            temp.printGetty();
            
            //print binary tree (without omitted words) with an inorder traversal
            temp.inTravPrintTree();
            
            try {
                search.queryHeader();
                search.startQuery();
            }
            catch (WordNotFoundException e) {       
                System.out.println("Please try again with a different word.\n\n\n\n");
                search.queryHeader();
                search.startQuery();
            }
           
            hashRef.hashHeader();
            hashRef.printHashTable();
            hashRef.printHashDescription();
            
            pw.close();
    }
}
