
/**
 * A custom exception class which extends Java's RuntimeException Class if an invalid word is input
 * into the querying system.
 * 
 * @author Evan Smith 
 * @version 5/19/17
 */
public class WordNotFoundException extends RuntimeException {    

    /**
     * Default constructuor calls the super method of RunTimeException Class
     * 
     */ 
    

    public WordNotFoundException() {
        super();
    }
    
    /**
     * One-arg constructor prints a custom message if a word is not found in binary search tree
     * 
     * @param  word   word scanned by user in the Query Class
     */
    public WordNotFoundException(String word) {

        System.out.printf("There is no such word '%s' found in the getty.txt file\n", word);    
        
    }
}