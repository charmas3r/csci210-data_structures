import java.io.*;

/**
 * Hash class is a set of methods used to implement a hash table of omitted words in the Gettysburg 
 * Address. Omitted words are mapped into the hash table using a hash code determined in the getHashCode 
 * method. For purposes of the lab this hash table is composed of String objects. Collisions are resolved
 * using linear probing.
 * 
 * @author Evan Smith 
 * @version 5/19/2017
 */
public class Hash
{
    private final static int TABLESIZE = 37;
    
    private PrintWriter pw;
    private String[] hashTable;
    private int hashValue;
    private int hashCode;
    private int hashCollisions;
    private int resolutionCollisions;
    private int totalCollisions;

    /**
     * One-arg constructor for the Hash Class, initializes all the instance varibles used in the class
     * 
     * @param   pw  PrintWriter object
     */
    public Hash(PrintWriter pw)
    {
        this.pw = pw;
        this.hashTable = new String[TABLESIZE];
        
        this.hashValue = 0;
        
        this.hashCollisions = 0;
        this.resolutionCollisions = 0;
        this.totalCollisions = 0; 
    }
    
    /**
     * This method simply maps a string into the hash table by determining its hash code and then performing
     * an insertion with each respective method.
     * 
     * @param  key   String to be transformed
     */
    public void map(String key) {
        hashValue = getHashCode(key);
        insert(key, hashValue);
    }

    /**
     * This method inserts a string with a hash code that's been determined by the hash function into
     * the hash table. This method uses linear probing to resolve collisions and records hash function
     * collisions as well as resolution collisions. 
     * 
     * @param  key   String to be transformed
     * @param  hashValue    hash code determined by the hash function
     */
    public void insert(String key, int hashValue) {
        int probeValue = hashValue;

        //save hash function collisions
        if (hashTable[hashValue] != null) 
            hashCollisions++;            
           
        while (hashTable[probeValue] != null) {  
             //save resolution collision
             if (hashTable[probeValue] != hashTable[hashValue])
                 resolutionCollisions++;
                    
             probeValue++;
             probeValue %= TABLESIZE; //wrap code
        }
            
        if (hashTable[probeValue] ==  null)
                hashTable[probeValue] = key;

        totalCollisions = hashCollisions + resolutionCollisions;
    }

    /**
     * This method is a boolean search operation to find if a string key is contained within the 
     * hash table. 
     * 
     * @param  key   String to be transformed
     * @return boolean value false if word is not found
     */
    public boolean search(String key) {
        hashValue = getHashCode(key);
        
        int probeValue = hashValue;
        
        while (hashTable[probeValue] != null) {
            
            if (hashTable[hashValue].equals(key))
                return true;
                
            probeValue++;             
            probeValue %= TABLESIZE; //wrap code   
        }
        
        return false;
    }
    
    /**
     * This method transformes the string key to a integer which is the sum of the character values 
     * and then performs various bitwise operators to produce a hash code for each sum that will be
     * as unique as possible.
     * 
     * @param  key   String to be transformed
     * @return     hash code of the key
     */
    public int getHashCode(String key)
    {
        //must wipe previous sum for each new node hashcode
        int sum = 0; 
        int M = 31;  //Mersenne prime
        
        for (int i = 0; i < key.length(); i++) 
            sum += M * (int) key.charAt(i);

        hashCode = ((sum ^ 2) * 106); //2
        hashCode %= TABLESIZE;

        return hashCode;
    }
 
    /**
     * This method describes the hash function in more detail
     * 
     */
    public void printHashDescription() {
        
        System.out.println("\n\n");
        System.out.println("HASH FUNCTION DESCRIPTION: \n");
        System.out.println("This hash function works by adding the ASCII character values at each index");
        System.out.println("(multiplied by a Mersenne prime number of 31) to a sum integer. This sum integer"); 
        System.out.println("is then transformed through a bitwise operation to produce a hash code with only");
        System.out.println("7 hash function collisions and 1 resolution collision. The sum is transformed");
        System.out.println("through a XOR function of 2 and then multiplied by the integer 106. Integer division");
        System.out.println("by 37 (the table size) is then performed on the hash code and remainder is saved ");
        System.out.println("as the hash code. This is done using the MOD operator. \n");
        
        pw.println("\n\n");
        pw.println("HASH FUNCTION DESCRIPTION: \n");
        pw.println("This hash function works by adding the ASCII character values at each index");
        pw.println("(multiplied by a Mersenne prime number of 31) to a sum integer. This sum integer"); 
        pw.println("is then transformed through a bitwise operation to produce a hash code with only");
        pw.println("7 hash function collisions and 1 resolution collision. The sum is transformed");
        pw.println("through a XOR function of 2 and then multiplied by the integer 106. Integer division");
        pw.println("by 37 (the table size) is then performed on the hash code and remainder is saved ");
        pw.println("as the hash code. This is done using the MOD operator. \n");
        
    }
    
    /**
     * This method prints the hashing table header
     *
     */
    public void hashHeader() {
        System.out.println("\n\n");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("                     WELCOME TO THE HASHING TABLE                        ");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("\n\n");

        pw.println("\n\n");
        pw.println("-------------------------------------------------------------------------");
        pw.println("                     WELCOME TO THE HASHING TABLE                        ");
        pw.println("-------------------------------------------------------------------------");
        pw.println("\n\n");

    }
    
    /**
     * This method prints the hashing table sub header
     *
     */
    public void hashHeader2() {
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("%-13s %-10s\n", "Code", "Key");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println();
        
        pw.println("-------------------------------------------------------------------------");
        pw.println(String.format("%-13s %-10s", "Code", "Key"));
        pw.println("-------------------------------------------------------------------------");
        pw.println();
    }
    
    /**
     * This method prints the hash table with all the values from the omit.txt file as well as
     * the statistics of the collisions produced by the hash function.
     *
     */
    public void printHashTable(){
        hashHeader2();
        
        for(int i = 0; i < TABLESIZE; i++){
            //fill in values
            if(hashTable[i] != null){
                System.out.printf("%-13d %-10s\n", i, hashTable[i]);
                pw.println(String.format("%-13s %-10s", i, hashTable[i]));
                
            }
            
            // if empty bucket 
            else {
                System.out.printf("%-13d %-10s\n", i, "-");
                pw.println(String.format("%-13s %-10s", i, "-"));
            }
        }

        System.out.println("\n");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("      COLLISION STATISTICS: ");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println();
        System.out.println("Hash function collisions: " + hashCollisions);
        System.out.println("Resolution collisions: " + resolutionCollisions);
        System.out.println("Total collisions: " + totalCollisions);

        pw.println("\n");
        pw.println("-------------------------------------------------------------------------");
        pw.println("      COLLISION STATISTICS: ");
        pw.println("-------------------------------------------------------------------------");
        pw.println();
        pw.println("Hash function collisions: " + hashCollisions);
        pw.println("Total collisions: " + totalCollisions);
    
    }
}
