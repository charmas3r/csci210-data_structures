import java.io.*;

/**
 * Word Class contains a set of methods to get and set Word atrributes as determined by the Binary Tree Lab as well as three methods (visit, operate and compareTo)
 * which are used in the ObjectBinaryTree class. These methods are especially important in construction of the binary search tree, determining how to handle duplicates 
 * and how print objects held in the tree during a traversal. 
 * 
 * @author Evan Smith
 * @version 5/19/2017
 */
public class Word implements TreeComparable 
{
    // instance variables - replace the example below with your own
    private PrintWriter pw;
    
    private int wordCount;
    private String gettyWord;
    private ObjectList linePositionList;
    
   /**
    * This is a one-arg constructor for Word which creates an empty word object
    * 
    *@param pw  PrintWriter object
    */
    public Word(PrintWriter pw) {
        this.gettyWord = "";
        this.wordCount = 0;
        this.linePositionList = new ObjectList();
    }
    
       /**
    * Word Constructor is one-arg contstructor that initializes a string
    *
    * @param gettyWord string to be initialized
    */
   public Word (String gettyWord) {
       
        this.gettyWord = gettyWord;
    
    }
    
   /**
     * Constructor for objects in the Word Class initialize all instance variables for the Word class 
     * 
     * @param gettyWord string from getty text
     * @param wordCount how many times word appears in text
     * @param linePositionList  ObjectList contains line number and word position
     * @param PrintWriter pw PrintWriter object passed by Driver class
     */
    public Word(String gettyWord, int wordCount, ObjectList linePositionList, PrintWriter pw)
    {
        this.gettyWord = gettyWord;
        this.wordCount = wordCount;
        this.linePositionList = linePositionList;
        this.pw = pw;
    }
    
    /**
     * This method returns the number of times a word appears in getty text
     *
     * @returns wordCount number of times word appears in text
     */
    public int getWordCount() {
        
        return wordCount;

    }
    
    /**
     * This method returns the gettyWord
     * 
     * @return gettyWord string of gettyWord
     */
    public String getWord() {
        
        return gettyWord;

    }
    
    /**
     * This method returns the ObjectList which contains the word position and line number
     * 
     * @return linePositionList word position and line number
     */
    public ObjectList getList() {
        
        return linePositionList;

    }
    
    /**
     * This method compares the gettyWord object to another word lexigraphically. Used in the ObjectBinaryTree class.
     * 
     * @param   Object the gettyWord is to be compared to
     * @returns int 1, 0 or -1
     */
    public int compareTo(Object o) {
    
        Word temp = (Word) o;
        return gettyWord.compareTo(temp.getWord());
       
    }
    
    /**
     * This method prints the gettyWord string, word count, line position and word position all the in the recommended format for the lab
     * 
     */
    public void visit() {
        System.out.printf("%-15s %-8d ", 
                    gettyWord, 
                    wordCount);          
                               
        pw.printf(String.format("%-15s %-8d ", 
                    gettyWord, 
                    wordCount));
                    
        //word, count and linked list info is all printed. 
        ObjectListNode p = linePositionList.getFirstNode();
        while (p != null) {
            LinePosition temp = (LinePosition) p.getInfo();
            
            System.out.print(temp.getLineNumber() + "-" + temp.getWordPosition() + " ");
            pw.print(temp.getLineNumber() + "-" + temp.getWordPosition() + " ");
    
            p = p.getNext();        
        }
        
        System.out.println();
        pw.println();
    }
    
    /**
     * This method determines what happens if a duplicate word is seen. The word object is added to the ObjectList and word count is increased.
     *
     * @param o duplicate word object
     */
    public void operate(Object o) {
        //set temp word to object
        Word temp = (Word) o;
        
        ObjectListNode p = temp.getList().getFirstNode();
        
        wordCount++;
        linePositionList.addLast(p);
    }
}
