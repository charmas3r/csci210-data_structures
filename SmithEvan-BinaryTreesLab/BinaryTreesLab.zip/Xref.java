import java.io.*;
import java.util.*;

/**
 * Xref class contains a set of methods to be used in the Binary Tree Lab. Specifically these methods
 * parse a text file containing the Gettysburg Address building a binary search tree of word objects
 * which contain the string word, word count, line number and word position. A hash table is also built in this
 * class which is made of words to be omitted in the querying of the text. Formatting is fixed to specifications
 * presented in the lab and can be found on pages 453-457 of Stegman's book "Focus on Data Structures". 
 * 
 * @author Evan Smith
 * @version 5/19/17
 */
public class Xref
{
    private int lineNumber;
    private int wordCount;
    private ObjectList linePositionList;
    private ObjectBinaryTree tree;
    private PrintWriter pw;
    private Hash hashTable;


    /**
     * Constructor for objects of class Word
     * 
     * @param Hash  hash class object initialized in the driver class
     * @param PrintWriter   printwriter object initialized in the driver class
     */
    public Xref(Hash hashRef, PrintWriter pw)
    {
        // initialise instance variables
        wordCount = 1;
        lineNumber = 0;
        
        this.tree = new ObjectBinaryTree();
        this.linePositionList = new ObjectList();
        this.pw = pw;
        this.hashTable = hashRef;
    }

    /**
     * This method parses the gettyText and creates a binary search tree of Word objects which contain the 
     * string of the word, word count, line position, word position, and the printwriter object created in 
     * the driver class. Before a word is added it is verified that it is not in the hash table of omitted 
     * words. 
     * 
     * @throws InterruptedException
     * @throws IOException
     */
    public void parseFile() throws InterruptedException, IOException {
        Scanner fileScan = new Scanner(new File("getty.txt"));
        
        while(fileScan.hasNext()){
            String buf = fileScan.nextLine(); //get whole line
            // remove punctuation, letter casing and split line into word tokens
            String[] tokens = buf.replaceAll("[-,;.]", "").toLowerCase().split("\\s+"); 
            lineNumber++;
            
            for (int i = 0; i < tokens.length; i++) {
                //add each word object, word count, and list to a binary tree
                //linePosition object keeps track of line number and word position
                //word position is always one more than the index of the token word
                       
                if (hashTable.search(tokens[i]) == false) {
                    LinePosition temp1 = new LinePosition(lineNumber, i + 1);
                    ObjectList temp = new ObjectList();
                    temp.addLast(temp1);
                    Word temp2 = new Word(tokens[i], wordCount, temp, pw);
                    //must use insertBSTDup method to trigger the operate method in Word class
                    tree.insertBSTDup(temp2);   
                    }
            }
            
        }
        fileScan.close();
    } 
    
    /**
     * Method omitFile parses the omitted word list supplied by Professor Stegman for this lab and inserts 
     * them into the hash table using a mapping method within the Hash class.
     * 
     * @throws InterruptedException
     * @throws IOException
     */
    public void printGetty() throws InterruptedException, IOException {  
        
        gettyHeader();
        
        Scanner sc = new Scanner(new File("getty.txt"));
        
        int lineNumberTemp = 1;
        while(sc.hasNext()) {
            String buf = sc.nextLine();
 
            System.out.printf("%-2d  %s\n", lineNumberTemp, buf);    
            pw.println(String.format("%-2d  %s", lineNumberTemp, buf));  
            
            lineNumberTemp++;
        }
        
        System.out.println("\n\n");
        pw.println("\n\n");
    }
    
     /**
     * Method omitFile parses the omitted word list supplied by Professor Stegman for this lab and inserts 
     * them into the hash table using a mapping method within the Hash class.
     * 
     * @throws InterruptedException
     * @throws IOException
     */
    public void omitFile() throws InterruptedException, IOException {     
        Scanner sc = new Scanner(new File("omit.txt"));
        
        while(sc.hasNext()) {
            String buf = sc.nextLine();
            String[] tokens = buf.split("\\s+");
            
            for (int i = 0; i < tokens.length; i++)
                hashTable.map(tokens[i]);
        }
    }
        
    /**
     * Method getTree returns a binary search tree 
     *
     * @return tree Binary search tree needed to query words in the Query class
     */
    public ObjectBinaryTree getTree() {
        return tree;
    }
    
    /**
     * Method inTravPrintTree performs an inorder traversal of the binary search tree created in the parseFile 
     * method printing all objects alphabetically using the inTrav method visit method.
     *
     */
    public void inTravPrintTree () {
        headerOutput2();
        ObjectTreeNode p = tree.getRoot();
        tree.inTrav(p);
        
        System.out.println("\n\n");
        pw.println("\n\n");
    }
    
    /**
     * Method headerOutput creates the primary header for the lab
     *
     */
    public void headerOutput() {
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("              WELCOME TO THE BINARY TREE AND HASHING LAB                 ");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("\n\n");

        
        
        pw.println("-------------------------------------------------------------------------");
        pw.println("              WELCOME TO THE BINARY TREE AND HASHING LAB                 ");
        pw.println("-------------------------------------------------------------------------");
        pw.println("\n\n");

    }
    
        /**
     * Method prints the header for the Gettysburg Address 
     * 
     */
    public void gettyHeader() {
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("                         THE GETTYSBURG ADDRESS                          ");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println();
        
        pw.println("-------------------------------------------------------------------------");
        pw.println("                         THE GETTYSBURG ADDRESS                          ");
        pw.println("-------------------------------------------------------------------------");
        pw.println("");
    }
    
    /**
     * Method prints the sub header for displaying word count and line position during the inorder traversal
     * 
     */
    public void headerOutput2() {
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("%-13s %-10s %-20s \n", "WORD", "COUNT", "LINE POSITION - WORD POSITION");
        System.out.println("-------------------------------------------------------------------------");
        
        pw.println("-------------------------------------------------------------------------");
        pw.println(String.format("%-13s %-10s %-20s \n", "WORD", "COUNT", "LINE POSITION - WORD POSITION"));
        pw.println("-------------------------------------------------------------------------");
       
    }

}