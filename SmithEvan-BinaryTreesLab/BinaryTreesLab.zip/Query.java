import java.io.*;
import java.util.*;

/**
 * The Query Class performs runtime queries on words within the Gettysburg Address, outputting the string word
 * if found, the line number and word position. Query Class is built to handle runtime exceptions of queries
 * for words that have been omitted in the Gettysburg Address and can handle non-word strings aswell.
 * 
 * @author Evan Smith
 * @version 5/19/17
 */
public class Query
{
    private PrintWriter pw;
    private Xref ref;
    private Hash hashRef;
    
    /**
     * Constructor initializes the instances variables one of which is the Xref object created in the Driver
     * class.
     * 
     * @param  pw   PrintWriter object created in Driver class
     * @param ref   Xref object created in the Driver class
     */
    public Query(Xref ref, PrintWriter pw, Hash hashRef) {
        this.pw = pw;
        this.ref = ref;
        this.hashRef = hashRef;
    }
    
    /**
     * Method prints the primary header of the Query Class
     * 
     */
    public void queryHeader() {
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("                 WELCOME TO THE WORD QUERYING SYSTEM                     ");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println("\n\n");
        
        pw.println("-------------------------------------------------------------------------");
        pw.println("                  WELCOME TO THE WORD QUERYING SYSTEM                    ");
        pw.println("-------------------------------------------------------------------------");
        pw.println("\n\n");
    }
    
    /**
     * Method prints the sub header of the Query Class
     * 
     */
    public void queryHeader2() {
        System.out.println();
        System.out.println("-------------------------------------------------------------------------");
        System.out.printf("%-13s %-10s %-20s \n", "WORD", "COUNT", "LINE POSITION - WORD POSITION");
        System.out.println("-------------------------------------------------------------------------");
        System.out.println();
        
        pw.println();
        pw.println("-------------------------------------------------------------------------");
        pw.println(String.format("%-13s %-10s %-20s \n", "WORD", "COUNT", "LINE POSITION - WORD POSITION"));
        pw.println("-------------------------------------------------------------------------");
        pw.println();
    }
    
    /**
     * startQuery method scans a word from the user input and then searches the binary tree built from
     * the words of the Gettysburg Address. If the word is found it will output the word, line position and
     * word position.
     * 
     * @throws WordNotFoundException    custom exception class to catch runtime errors 
     */
    public void startQuery() throws WordNotFoundException{
        ObjectBinaryTree tree = ref.getTree();
        
        Scanner sc = new Scanner(System.in);
        String choice = "y";
        while (choice.equalsIgnoreCase("y")) { 
            System.out.println("Enter a word from the Getty.txt file: ");
            pw.println("Enter a word from the Getty.txt file: ");
            
            String gettyWord = sc.nextLine();
  
            Word temp = new Word(gettyWord.toLowerCase()); //create temp word object from scanned in word
            ObjectTreeNode test = tree.searchBST(temp); //search fully built Tree object for word
            
            if (hashRef.search(gettyWord) == true) {
                System.out.println();
                System.out.println("This word has been omitted from the search function per lab instruction\n");
                
                pw.println();
                pw.println("This word has been omitted from the search function per lab instruction\n");
            }

            if (test == null) 
                throw new WordNotFoundException(gettyWord);
            
            //get current word object from tree.
            else {
                queryHeader2();  
                
                Word tester = (Word) test.getInfo();
                ObjectListNode p = tester.getList().getFirstNode();
            
                System.out.printf("%-15s %-8d ", 
                    tester.getWord(), 
                    tester.getWordCount());          
                               
                pw.printf(String.format("%-15s %-8d ", 
                    tester.getWord(), 
                    tester.getWordCount()));

                while (p != null) {
                    LinePosition temp2 = (LinePosition) p.getInfo();

                    System.out.print(temp2.getLineNumber() + "-" + temp2.getWordPosition() + " ");
                    pw.print(temp2.getLineNumber() + "-" + temp2.getWordPosition() + " ");
                
                    p = p.getNext();
                }          
            }
            System.out.println("\n\n");
            pw.println("\n\n");

            //prompt user to continue
            System.out.println("Try another word? (y/n): ");
            pw.println("Try another word? (y/n): ");
            
            choice = sc.nextLine();
        }
        sc.close();
    }
}
