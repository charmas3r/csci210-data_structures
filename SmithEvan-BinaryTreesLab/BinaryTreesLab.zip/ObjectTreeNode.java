
/**
 * ObjectTreeNode class contains a set of methods to be used in the implemention of binary tree data structure.
 * Specifically these methods contain the necessary initializers, getters and setters for a node within 
 * a binary tree.
 * 
 * @author Evan Smith
 * @version 5/16/17
 */

public class ObjectTreeNode implements ObjectTreeNodeInterface {
    private Object info;
    private ObjectTreeNode left;
    private ObjectTreeNode right;
    
    /**
     * Default constructor initials all values of the node to null
     * 
    */
    public ObjectTreeNode() {
        info = null;
        left = null;
        right = null;
    }
    
    /**
     * One-arg constructor sets the info field to an Object passed as a parameter and other fields set to null
     * 
     * @param   Object  object to be passed into info field
    */
    public ObjectTreeNode (Object o) {
        info = o;
        left = null;
        right = null;
    }
    
    /**
     * This method sets the info field of a tree to an Object value
     * 
     * @param   Object  object to be passed into info field
    */
    public void setInfo(Object o) {
        info = o;
    }
    
    /**
     * This method returns the data object held in the info field
     * 
     * @return   Object data object held in the info field
    */
    public Object getInfo() {
        return info;
    }
    
    /**
     * This method sets the left field in a tree node to point to a new child
     * 
     * @param   ObjectTreeNode node left is set to
    */
    public void setLeft(ObjectTreeNode p) {
        left = p;
    }
    
    /**
     * This method returns the tree node pointed to in the left field
     * 
     * @return   ObjectTreeNode node pointed to in left field
    */
    public ObjectTreeNode getLeft() {
        return left;
    }
    
    /**
     * This method sets the right field in a tree node to point to a new child
     * 
     * @param   ObjectTreeNode node right is set to
    */
    public void setRight(ObjectTreeNode p) {
        right = p;
    }
    
    /**
     * This method returns the tree node pointed to in the right field
     * 
     * @return   ObjectTreeNode node pointed to in right field
    */
    public ObjectTreeNode getRight() {
        return right;
    }
}



// ObjectBinaryTree.java
