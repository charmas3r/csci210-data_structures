
/**
 * LinePosition class contains a set of getting and setting methods for the line position and word position.
 * Line position is determined by what line the word in the getty text is found on and word position is how
 * many words it is from the first word in that line.
 * 
 * @author Evan Smith   
 * @version 5/19/2017
 */
public class LinePosition
{
    private int lineNumber;
    private int wordPosition;

    /**
     * LinePosition Constructor initializes line number and word position to zero
     *
     */
    public LinePosition() {
        this.lineNumber = 0;
        this.wordPosition = 0;
    }
    
    /**
     * LinePosition Constructor
     *
     * @param lineNumber line the string is on
     * @param wordPosition number of times the word occurs in text
     */
    public LinePosition(int lineNumber, int wordPosition)
    {
        this.lineNumber = lineNumber;
        this.wordPosition = wordPosition;
    }

    /**
     * Method getLineNumber returns what line the word is on
     *
     * @return lineNumber what line the word is on
     */
    public int getLineNumber()
    {
        return lineNumber;
    }

    /**
     * Method getWordPosition returns what the word position the string has in the text on a certain line
     *
     * @return word position of gettyWord
     */
    public int getWordPosition()
    {
        return wordPosition;
    }
    
}
