import java.io.*;
import java.util.Scanner;

/**
 * Driver Class scans in a series of infix expressions, then passes them to other classes 
 * for evaluation and then prints the orginal infix expression, converted postfix expression
 * and then the evaluated result of the postfix expression.
 * 
 * @author Evan Smith   
 * @version 3/10/2017
 */
public class Driver 
{
    public static void main(String args[]) throws IOException {

        Scanner fileScan = new Scanner(new File("infix.txt"));
        PrintWriter pw = new PrintWriter(new FileWriter("csis.txt"));
        
        while (fileScan.hasNext()) {
            
            String buf = fileScan.nextLine();
            buf = buf.replaceAll("\\s+", ""); // gets rid of white spaces

            InfixToPostfix in = new InfixToPostfix(buf);
            String postfix = in.toPostfix();

            EvalPostfix eval = new EvalPostfix(postfix); 
            int result = eval.evalPostfix();
            
            System.out.println("Infix expression: " + buf);
            pw.print("Infix expression: ");
            pw.println(buf);
            
            System.out.println("Postfix expression: " + postfix);
            pw.print("Infix expression: ");
            pw.println(postfix);
            
            System.out.println("Result: " + result);
            pw.print("Result: ");
            pw.println(result);
            
            System.out.println("\n");
            pw.println();
            pw.println();
            
        }
       
        fileScan.close();
        pw.close();
    }
}
