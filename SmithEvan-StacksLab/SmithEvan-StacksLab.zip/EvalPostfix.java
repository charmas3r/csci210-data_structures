
/**
 * EvalPostfix evaluates a postfix expression, returning the result as an integer
 * 
 * @author Evan Smith
 * @version 3/10/17
 */
public class EvalPostfix
{
    String postfix;
    private ObjectStack operand;

    /**
     * Constructor for objects of class EvalPostfix
     * 
     * @param postfix  postfix expression to be evaluated
     */
    public EvalPostfix(String postfix)
    {
        this.postfix = postfix;
        this.operand = new ObjectStack();
    }

    /**
     * evalPostfix evaluates a postfix expression
     * 
     * @return  integer result of the postfix expression
     */
    public int evalPostfix()
    { 
    
        StringBuilder eval = new StringBuilder();
        eval.append("");
    
        //parse the expression from left to right
        for (int i = 0; i < postfix.length(); ++i) {

            //break up string into characters for parsing
            char temp = postfix.charAt(i);
          
            //when operand is encountered it gets pushed on the stack
            if (temp >= '0' && temp <= '9') {
              operand.push(temp - 48);
            }
        
            //else is operator...
            else {
                int op2 = ((Integer)operand.pop());
                int op1 = ((Integer)operand.pop());
               
                int x = 0;
              
                //performs operations... (change if's..)
                 if (temp == '^') {
                    double d = Math.pow((double) op1, (double) op2);
                    x = (int) d;
                 }   
                  
                 if (temp == '*')
                    x = (op1 * op2);
                  
                 if (temp == '/')
                    x = (op1 / op2);
                  
                 if (temp == '+')
                    x = (op1 + op2);
                  
                 if (temp == '-')
                    x = (op1 - op2);
                  
                operand.push(x);
            } 
         }

        // last number in stack should be the result. 
        int result = ((Integer)operand.pop());

        return result;
    }  
}
