
/**
 * ObjectStack is a single stack class that can hold objects of any type
 * 
 * @author Evan Smith
 * @version 3/10/2017
 */
public class ObjectStack implements ObjectStackInterface
{
    private Object[] item;
    private int top;

    /**
     * Constructor for objects of class ObjectStack
     */
    public ObjectStack()
    {
        item = new Object[1];
        top = -1;
    }

    /**
     * isEmpty evaluates if the stack is empty
     * 
     * @return    false if top does not equal -1 
     */
    public boolean isEmpty()
    {
        return top == -1;
    }
    
    /**
     * isFull evaluates if the stack is full
     * 
     * @return    false if top does not equal item array max size     
     */
    public boolean isFull()
    {
        return top == item.length-1;
    }
    
    /**
     * clear method resets the Object stack setting top to -1
     * 
     */
    public void clear()
    {
        item = new Object[1];
        top = -1;
    }
    
        /**
     * An example of a method - replace this comment with your own
     * 
     * @param    0    Object to be pushed onto stack
     */
    public void push(Object o)
    {
        if (isFull())
            resize(2 * item.length);
        item[++top] = o;
    }
    
    /**
     * resize method doubles the array once the stack is filled 
     * 
     * @param    size   size of the array
     */
    private void resize(int size)
    {
        Object[] temp = new Object[size];
        for (int i = 0; i <= top; i++)
            temp[i] = item[i];
        item = temp;
    }
    
    /**
     * pop method removes the top Object in the stack and returns it
     * 
     * @return     removed top item of the stack
     */
    public Object pop()
    {
        if (isEmpty()) {
            System.out.println("Stack Underflow.");
            System.exit(1);
        }
        Object temp = item[top];
        item[top--] = null;
        if (top == item.length/4)
            resize(item.length/2);
        return temp;
       
    }
    
    /**
     * top methods returns the top Object in the stack without removing it (peeking).
     * 
     * @return     a "peek" of the top Object of the stack
     */
    public Object top()
    {
        if (isEmpty()) {
            System.out.println("Stack Underflow");
            System.exit(1);
        }
        return item[top];
    }
}
