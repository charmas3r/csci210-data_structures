
/**
 * InfixToPrefix converts an infix expression to a prefix expression
 * 
 * @author Evan Smith 
 * @version 3/10/2017
 */
public class InfixToPostfix
{
    String infix;
    private ObjectStack s;
    
    /**
     * Constructor for objects of class InfixToPostfix
     * 
     * @param infix   infix string read in from scanner in Driver class
     */
    public InfixToPostfix(String infix)
    {
        this.infix = infix;
        this.s = new ObjectStack();
    }

    
    /**
     * toPostfix converts an infix expression to a postfix expression
     * 
     * @return converted postfix expression as string 
     */
    public String toPostfix()
    {
        
        StringBuilder postfix = new StringBuilder();
        postfix.append("");

        for (int i = 0; i < infix.length(); ++i) {
            
            //looking at each character in the infix string
            char temp = infix.charAt(i);
            
            // scan infix expression when operand is encountered, copy it immeadiately to the postfix expression
            if (temp >= '0' && temp <= '9')
                postfix.append(temp);
       
            // When a left paraenthesis is encountered in the infix expression, push it onto the stack.

            else if (temp == '(') 
               s.push(temp); // automatic cast up to Big Object
            
            // when a right parenthesis is encountered in the infix expression, pop the operators and place
            // them in the postfix expression until a left paranthesis is encountered on the stack. Discard
            // both left and right parenthesis.
            
            else if (temp == ')') {
                while ((!s.isEmpty()) && ((Character)s.top()) != '(') 
                    postfix.append(s.pop());         
                s.pop(); //pop off left parenthesis
            }
            
            // When an operator is encountered in the infix expression, pop the operators from the stack  
            // and place them in the postfix expression until either stack is empty or the operateor on top 
            // of the stack has a lower priority than the operator encountered in the infix expression. 
       

            else {
                  
                   while (!s.isEmpty() && priority((Character)s.top()) >= priority(temp)) {
                         if ((Character)s.top() == '(') 
                             break;
                    
                         if (priority((Character)s.top()) >= priority(temp))
                                postfix.append(s.pop());   
                  } 
                   s.push(temp);
            }   
        }   
   
        // when the entire infix expression has been scanned, pop operators from the stack and place 
        // them in the posfix expression until the stack is empty.
           
        while (!s.isEmpty()) 
            postfix.append(s.pop());
   
        return postfix.toString();   
    }
    
    /**
     * priority method evaluates the priority of operators
     * 
     * @param op   operator to be evaluated
     * @return  precedence of operator as integer 
     */
    private int priority(char op)
    {
        switch (op) {
            case '^': return 3;
            case '*': return 2;
            case '/': return 2;
            case '+': return 1;
            case '-': return 1;
            default: return 0;
        }
    }
    


}
