import java.io.*;
import java.util.*;

public class Menu
{
    private PrintWriter pw;

    /**
     * Constructor for objects of class Menu
     */
    public Menu(PrintWriter pw)
    {
        this.pw = pw;
    }

    /**
     * Displays menu selection
     *  
     */
    public void display()throws IOException
    {
        
        System.out.println( "1) Decimal to Binary\n");
        pw.println( "1) Decimal to Binary\n"); 
        
        System.out.println( "2) Decimal to Hex\n"); 
        pw.println( "2) Decimal to Hex\n"); 
        
        System.out.println( "3) Binary to Decimal\n"); 
        pw.println( "3) Binary to Decimal\n"); 
        
        System.out.println( "4) Binary to Hex\n"); 
        pw.println( "4) Binary to Hex\n"); 
        
        System.out.println( "5) Hex to Decimal\n");
        pw.println( "5) Hex to Decimal\n");
        
        System.out.println( "6) Hex to Binary\n"); 
        pw.println( "6) Hex to Binary\n"); 

    }
    
        /**
     * Gets menu selection
     * 
     * @return  choice  menu selection inputted by user.
     */
    public int getSelection()
    {
        Scanner sc = new Scanner (System.in);
        
        System.out.println( "Selection: ");
        int choice = sc.nextInt();
               
        pw.print( "Selection: ");
        pw.println(choice);
        
        //error coding needed to make sure input is between 1-6
        
        sc.close();
        return choice;

    }
}
