import java.io.*; //for PrintWriter, IOException
import java.util.*; //for Scanner

/**
 * Converts hexadecimal numbers to decimal and binary numbers
 * 
 * @author Evan Smith
 * @version  2/15/17
 */
public class Hexadecimal
{
    private PrintWriter pw;

    /**
     * Constructor for objects of class Decimal
     * 
     * @param   pw      PrintWriter object passed by Driver class
     */
    public Hexadecimal(PrintWriter pw)
    {
        this.pw = pw;
    }

    /**
     * Converts a hexadecimal number to a decimal number
     * 
     */
    public void hexToDec() throws IOException
    {
        String hex = inputHex();
        int decimal = toDec(hex);
        outDec(decimal);
    }
    
        /**
     * Gets the hexadecimal number for conversion
     * 
     * @return  hex     hexadecimal scanned in by user for conversion
     */
    private String inputHex()
    {
        
        System.out.println( "Enter hexadecimal number for conversion: ");
        pw.print( "Enter hexadecimal number for conversion: ");
        Scanner sc = new Scanner(System.in);
        
        String hex = sc.nextLine(); //reads binary number
        pw.println(hex);
        
        sc.close();
       
        return hex;
    }
    
        /**
     * Hexadecimal to decimal algorthim
     * 
     * @param   hex     hexadecimal number for conversion
     * @return  decimal converted hex to decimal number
     */
    private int toDec(String hex)
    {        
              
        String hexAlpha = "0123456789ABCDEF";
        
        int decimal = 0;
        for (int i = 0; i < hex.length(); i++) {
            char c = hex.charAt(i);
            int temp = hexAlpha.indexOf(c);
            decimal = 16 * decimal + temp;
        }
        
        if (decimal < 0) {
            System.out.println( "Enter a valid hexadecimal number!" );
            inputHex();
        }
        
        if (decimal == 0) 
            return 0;
  
        return decimal;
    }
    

        /**
     * Outputs the decimal number that was converted
     * 
     * @param   decimal     converted hex to decimal number for output
     */
    private void outDec(int decimal) throws IOException
    {
        System.out.printf("Converted hexadecimal to decimal is: %d\n", decimal);
        pw.print("Converted hexadecimal to decimal is: ");
        pw.println(decimal);
    }
   
        /**
     * Converts a hexadecimal number to a binary number
     * 
     */
    public void hexToBin() throws IOException
    {
        StringBuilder bin = new StringBuilder();
        
        String hex = inputHex();
        bin = toBin(hex);
        outBin(bin);
    }
    
            /**
     * Hexadecimal to binary number algorthim 
     * 
     * @param   hex     hexadecimal number for conversion
     * @return  bin     converted hex to binary number
     */
    private StringBuilder toBin(String hex)
    {
        
        StringBuilder bin = new StringBuilder();    
        bin.append("");         
        
        for (int i = 0; i < hex.length(); i++) {
            
            
                if (hex.charAt(i) == '0')
                    bin.append("0000 ");
                else if (hex.charAt(i) == '1')
                    bin.append("0001 ");
                else if (hex.charAt(i) == '2')
                    bin.append("0010 ");
                else if (hex.charAt(i) == '3')
                    bin.append("0011 ");
                else if (hex.charAt(i) == '4')
                    bin.append("0100 ");
                else if (hex.charAt(i) == '5')
                    bin.append("0101 ");
                else if (hex.charAt(i) == '6')
                    bin.append("0110 ");
                else if (hex.charAt(i) == '7')
                    bin.append("0111 ");
                else if (hex.charAt(i) == '8')
                    bin.append("1000 ");
                else if (hex.charAt(i) == '9')
                    bin.append("1001 ");
                else if (hex.charAt(i) == 'A')
                    bin.append("1010 ");
                else if (hex.charAt(i) == 'B')
                    bin.append("1011 ");
                else if (hex.charAt(i) == 'C')
                    bin.append("1100 ");
                else if (hex.charAt(i) == 'D')
                    bin.append("1101 ");    
                else if (hex.charAt(i) == 'E')
                    bin.append("1110 ");
                else if (hex.charAt(i) == 'F')
                    bin.append("1111 ");
            
        }   
           
        return bin;
    
    }
    
            /**
     * Outputs the converted hexadecimal number as binary 
     * 
     * @param   hex    converted hex to binary number for output     
     */
        private void outBin(StringBuilder hex) throws IOException
    {
        System.out.printf("Converted hexadecimal to binary is: %s\n", hex);
        pw.print("Converted hexadecimal to binary is: ");
        pw.println(hex);
    }
    
}
