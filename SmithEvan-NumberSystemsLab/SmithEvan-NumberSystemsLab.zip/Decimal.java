import java.io.*; //for PrintWriter, IOException
import java.util.*; //for Scanner

/**
 * Converts decimal number to binary number.
 * 
 * @author Evan Smith
 * @version  2/15/17
 */
public class Decimal
{
    private PrintWriter pw;

    /**
     * Constructor for objects of class Decimal
     * 
     * @param   pw  PrintWriter object passed by Driver class
     */
    public Decimal(PrintWriter pw)
    {
        this.pw = pw;
    }

    /**
     * Converts a decimal number to a binary number
     * 
     */
    public void decToBin() throws IOException
    {
       
        int dec = inputDec();
        String binary = toBin(dec);
        outBin(binary);
    }
    
        /**
     * Gets the decimal number for conversion
     * 
     * @return  dec     decimal integer scanned by user
     */
    private int inputDec()
    {
        
        System.out.println( "Enter decimal number for conversion: ");
        pw.print( "Enter decimal number for conversion: ");
        Scanner sc = new Scanner(System.in);
        
        int dec = sc.nextInt(); //reads decimal integer
        pw.println(dec);        
        
        sc.close();
       
        return dec;
    }
    
        /**
     * Converts decimal number for conversion
     * 
     * @param   dec     scanned in deciaml defined by user
     * @return  binary  converted decimal to binary number
     */
    private String toBin(int dec)
    {
            
        if (dec <= 0) {
            System.out.println( "Enter a positive number!" );
            inputDec();
        }   
        
        String binary = "";  
        
        while (dec != 0){
            int rem = dec % 2;
            binary = rem + binary;
            dec = dec / 2;
            
        }
            
        return binary;
    }
    

        /**
     * Outputs the binary number that was converted
     * 
     * @param   binary  converted decimal to binary number
     */
    private void outBin(String binary) throws IOException
    {
        
        System.out.printf("Converted decimal to binary is: %s\n", binary);
        pw.print("Converted decimal to binary is: ");
        pw.println(binary);
        pw.println("\n\n");  
    }
   
        /**
     * Converts a decimal number to a hexadecimal number
     * 
     */
    public void decToHex() throws IOException
    {
        int dec = inputDec();
        String hex = toHex(dec);
        outBin(hex);
    }
    
            /**
     * Decimal to hexidecimal algorthim 
     * 
     * @param   dec     decimal number defined by user  
     * @hex     hex     converted decimal to hexadecimal number
     */
    private String toHex(int dec)
    {
             
        if (dec <= 0) {
            System.out.println( "Enter a positive number!" );
            inputDec();
        }
        
        if (dec == 0) 
            return "0";
            
        String hex = "";    
        char hexAlpha[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        
        while (dec != 0){
            int rem = dec % 16;
            hex = hexAlpha[rem] + hex;
            dec = dec / 16;
            
        }
        
        
        return hex;
    }
    
            /**
     * Outputs the decimal number that was converted to hexidecimal
     * 
     * @param       hex     converted decimal to hexadecimal number
     */
        private void outHex(String hex) throws IOException
    {
        
        System.out.printf("Converted decimal to hexadecimal is: %s\n", hex);
        pw.printf("Converted decimal to hexadecimal is: ");
        pw.println(hex);  
        pw.println("\n\n");  
        
    }
    
}
