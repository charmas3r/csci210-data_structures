import java.io.*; //for PrintWriter, IOException
import java.util.*; //for Scanner
import java.text.*;

/**
 * Converts binary number to decimal or hexadecimal number.
 * 
 * @author Evan Smith
 * @version  2/15/17
 */
public class Binary
{
    // instance variables - replace the example below with your own
    private PrintWriter pw;

    /**
     * Constructor for objects of class Binary
     * 
     * @param   pw  PrintWriter object passed in Driver class
     */
    public Binary(PrintWriter pw)
    {
        // initialise instance variables
        this.pw = pw;
    }

    /**
     * Converts a binary number to a decimal number
     * 
     */
    public void binToDec() throws IOException
    {
        String binary = inputBin();
        int decimal = toDec(binary);
        outDec(decimal);
    }
    
        /**
     * Gets the binary number for conversion
     * 
     * @return  binary  binary number scanned in by user
     */
    private String inputBin()
    {
      
        System.out.println( "Enter binary number for conversion: ");
        pw.print( "Enter binary number for conversion: ");
        Scanner sc = new Scanner(System.in);
        
        String binary = sc.nextLine(); //reads binary number
        pw.println(binary);
        
        sc.close();
       
        return binary;
    }
    
        /**
     * Binary to Decimal algorthim
     * 
     * @param   binary  binary number for conversion
     * @return  decimal converted binary to decimal number
     */
    private int toDec(String binary)
    {

        binary = new StringBuilder(binary).reverse().toString();
        
        int decimal = 0;
        for (int i = 0; i < binary.length(); i++) {
                int temp = (int)Math.pow(2, i);
                decimal = decimal +  Character.getNumericValue(binary.charAt(i)) * temp;
        } //converts binary to decimal
        
        if (decimal <= 0) {
            System.out.println( "Enter a valid binary number" );
            inputBin();
        }
        
        if (decimal == 0) 
            return 0;
            
            
        return decimal;
    }
    

        /**
     * Outputs the decimal number that was converted from binary
     * 
     * @param   dec     decimal number for output
     */
    private void outDec(int dec) throws IOException
    {
        System.out.printf("Converted binary to decimal is: %d\n", dec);
        pw.print("Converted binary to decimal is: ");
        pw.println(dec);
        pw.println("\n\n");  
    }

   
        /**
     * Converts a binary number to a hexadecimal number
     * 
     */
    public void binToHex() throws IOException
    {
        StringBuilder hex = new StringBuilder();
        
        String binary = inputBin();
        hex = toHex(binary);
        outHex(hex);
    }
    
            /**
     * Binary to hexidecimal algorthim 
     * 
     * @param   binary  binary number for conversion
     * @return  hex     converted binary to hex number
     */
    private StringBuilder toHex(String binary)
    {
         
        StringBuilder zero = new StringBuilder();
        zero.append("0");
        
        if (binary == "0") 
            return zero;
           
        StringBuilder hex = new StringBuilder();    
        hex.append("00000000");         
        
        for (int i = 0, j = 0; i < binary.length(); i += 4, j++) {
            
            
                if (binary.substring (i, i + 4).equals("0000"))
                    hex.setCharAt(j, '0');
                else if (binary.substring (i, i + 4).equals("0001"))
                    hex.setCharAt(j, '1');
                else if (binary.substring (i, i + 4).equals("0010"))
                    hex.setCharAt(j, '2');
                else if (binary.substring (i, i + 4).equals("0011"))
                    hex.setCharAt(j, '3');
                else if (binary.substring (i, i + 4).equals("0100"))
                    hex.setCharAt(j, '4');
                else if (binary.substring (i, i + 4).equals("0101"))
                    hex.setCharAt(j, '5');
                else if (binary.substring (i, i + 4).equals("0110"))
                    hex.setCharAt(j, '6');
                else if (binary.substring (i, i + 4).equals("0111"))
                    hex.setCharAt(j, '7');
                else if (binary.substring (i, i + 4).equals("1000"))
                    hex.setCharAt(j, '8');
                else if (binary.substring (i, i + 4).equals("1001"))
                    hex.setCharAt(j, '9');
                else if (binary.substring (i, i + 4).equals("1010"))
                    hex.setCharAt(j, 'A');
                else if (binary.substring (i, i + 4).equals("1011"))
                    hex.setCharAt(j, 'B');
                else if (binary.substring (i, i + 4).equals("1100"))
                    hex.setCharAt(j, 'C');
                else if (binary.substring (i, i + 4).equals("1101"))
                    hex.setCharAt(j, 'D');    
                else if (binary.substring (i, i + 4).equals("1110"))
                    hex.setCharAt(j, 'E');
                else if (binary.substring (i, i + 4).equals("1111"))
                    hex.setCharAt(j, 'F');
            
        }
        return hex;
    }
            
    
            /**
     * Outputs the binary number that was converted to hexidecimal
     * 
     * @param   hex     converted binary to hex number for output
     */
        private void outHex(StringBuilder hex) throws IOException
    {
        System.out.printf("Converted binary to hexadecimal is: %s\n", hex);
        pw.printf("Converted binary to hexadecimal is: ");
        pw.println(hex);
        pw.println("\n\n");
    }
    
}
